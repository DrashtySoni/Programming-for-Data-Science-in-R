# MDS273-PROGRAMMING-FOR-DATA-SCIENCE-IN-R

#Lab 1 - 
Describe Pkg | Available Pkg | Default Dir | Set Dir | Help on func,pkg | Example on func | List func | Expressions and assignments | ls() | Printing - Auto/Explicit | Remove Objects | Creating vector;checking type, class, is.integer and converting to integer | Tuple | TypeCasting | Vector Operations(sum,range,mean,var,sort,sqrt) | Sequence | Logical Operators | Missing Values | paste()-zip values
 
 #Lab 2 -
 Arithmetic Operations on vector | Vector with length | table() | sum,mean, maximum, minimum, range of the values , variance,sin of the elements in a vector | missing values | na.rm to get mean | Type conversion of vector | sequence | pattern
 
 #Lab 3 - Vector Operations
 - pos values from vector
 - neg values from vector
 - NA values
 - NAN values
 - create matrix

#Lab 4 - 
